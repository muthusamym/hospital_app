<h2>Appointment Confirmed</h2>
<p>Dear <?php echo e($appointment->patient->name); ?>,</p>
<p>Your appointment with Dr. <?php echo e($appointment->doctor->name); ?> has been scheduled on <?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('d M Y, h:i A')); ?>.</p>
<p>Thank you!</p>
<?php /**PATH C:\vsproject\laravel\healthcare-app\healthcare-app\resources\views/emails/appointment.blade.php ENDPATH**/ ?>